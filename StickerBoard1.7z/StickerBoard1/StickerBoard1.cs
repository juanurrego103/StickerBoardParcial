﻿using StickerBoard1;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
namespace StickerBoard1
{
    public partial class StickerBoard1 : Form
    {
        private List<Sticker> stickers = new List<Sticker>();

        public StickerBoard1()
        {
            InitializeComponent();
            InicializarControles();
            pbColor.BackColor = Color.Empty;
        }

        private void InicializarControles()
        {
            cmbSticker.Items.Clear();
            cmbSticker.Items.Add("Rectangulo");
            cmbSticker.Items.Add("Circulo");
            cmbSticker.Items.Add("Estrella");
            cmbSticker.Items.Add("Nube");
            cmbSticker.SelectedIndex = 0;

            nudX.Minimum = 0;
            nudY.Minimum = 0;

            nudX.Maximum = pblLienzo.Width;
            nudY.Maximum = pblLienzo.Height;
            nudSize.Maximum = Math.Max(pblLienzo.Width, pblLienzo.Height);

            txtContador.ReadOnly = true;
            txtContador.Text = "0";

            pblLienzo.Paint += PbLienzo_Paint;
            MessageBox.Show("Evento Paint conectado");
            pblLienzo.Invalidate();
            int lienzoW = pblLienzo.Width;

            btnCrear.Click += BtnCrear_Click;
            btnLimpiar.Click += BtnLimpiar_Click;
            pbColor.Click += PbColor_Click;
        }

        private void PbColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                pbColor.BackColor = colorDialog1.Color;
            }
        }

        private void BtnCrear_Click(object sender, EventArgs e)
        {
            try
            {
                if (pbColor.BackColor == Color.Empty)
                {
                    MessageBox.Show("Debe seleccionar un color antes de crear el sticker.", "Color requerido",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int x = (int)nudX.Value;
                int y = (int)nudY.Value;
                int size = (int)nudSize.Value;

                if (size == 0) // Cambiado para que el mensaje sea específico
                {
                    MessageBox.Show("El tamaño del sticker no puede ser 0.", "Tamaño inválido",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Aquí no suma al contador
                }

                int lienzoW = pblLienzo.Width;
                int lienzoH = pblLienzo.Height;

                if (x < 0 || y < 0 || (x + size) > lienzoW || (y + size) > lienzoH)
                {
                    MessageBox.Show("La posición o tamaño hace que la figura quede fuera del rango del lienzo.",
                        "Posición fuera de rango", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var tipo = (StickerFactory.TipoSticker)Enum.Parse(typeof(StickerFactory.TipoSticker), cmbSticker.SelectedItem.ToString());
                Sticker nuevo = StickerFactory.CrearSticker(tipo, x, y, size, pbColor.BackColor);

                stickers.Add(nuevo);
                txtContador.Text = stickers.Count.ToString();
                pblLienzo.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al crear sticker: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnLimpiar_Click(object sender, EventArgs e)
        {
            stickers.Clear();
            txtContador.Text = "0";
            pblLienzo.Invalidate();
        }

        private void PbLienzo_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            foreach (var s in stickers)
            {
                s.Dibujar(e.Graphics);  
            }
        }

        private void StickerBoard1_Resize(object sender, EventArgs e)
        {
            nudX.Maximum = pblLienzo.Width;
            nudY.Maximum = pblLienzo.Height;
            nudSize.Maximum = Math.Max(pblLienzo.Width, pblLienzo.Height);
        }

        private void pbColor_Click_1(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                pbColor.BackColor = colorDialog1.Color;
            }
        }

    }
}

