﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using static StickerBoard1.StickerBoard1;

namespace StickerBoard1
{
    public class StickerNube : Sticker
    {
        public StickerNube(int x, int y, int size, Color color)
            : base(x, y, size, color) { }

        public override void Dibujar(Graphics g)
        {
            using (SolidBrush brush = new SolidBrush(Color))
            {
                int r = Size / 3;
                g.FillEllipse(brush, X, Y + r, Size, r * 2);
                g.FillEllipse(brush, X + r, Y, r * 2, r * 2);
                g.FillEllipse(brush, X + r * 2, Y + r, r * 2, r * 2);
            }
        }
    }
}
