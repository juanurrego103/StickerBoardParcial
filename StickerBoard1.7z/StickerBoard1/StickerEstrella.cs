﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using static StickerBoard1.StickerBoard1;

namespace StickerBoard1
{
    public class StickerEstrella : Sticker
    {
        public StickerEstrella(int x, int y, int size, Color color)
            : base(x, y, size, color) { }

        public override void Dibujar(Graphics g)
        {
            using (SolidBrush brush = new SolidBrush(Color))
            {
                PointF[] puntos = CrearPuntosEstrella(X, Y, Size, Size / 2.5f, 5);
                g.FillPolygon(brush, puntos);
            }
        }

        private PointF[] CrearPuntosEstrella(float cx, float cy, float radioExterno, float radioInterno, int puntas)
        {
            PointF[] puntos = new PointF[puntas * 2];
            double angulo = -Math.PI / 2; // empieza hacia arriba
            double paso = Math.PI / puntas;

            for (int i = 0; i < puntas * 2; i++)
            {
                float radio = (i % 2 == 0) ? radioExterno : radioInterno;
                puntos[i] = new PointF(
                    cx + (float)(Math.Cos(angulo) * radio),
                    cy + (float)(Math.Sin(angulo) * radio)
                );
                angulo += paso;
            }
            return puntos;
        }
    }
}
