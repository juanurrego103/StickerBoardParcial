﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using static StickerBoard1.StickerBoard1;

namespace StickerBoard1
{
    public static class StickerFactory
    {
        public enum TipoSticker
        {
            Rectangulo,
            Circulo,
            Estrella,
            Nube
        }

        public static Sticker CrearSticker(TipoSticker tipo, int x, int y, int size, Color color)
        {
            switch (tipo)
            {
                case TipoSticker.Rectangulo:
                    return new StickerRectangulo(x, y, size, color);
                case TipoSticker.Circulo:
                    return new StickerCirculo(x, y, size, color);
                case TipoSticker.Estrella:
                    return new StickerEstrella(x, y, size, color);
                case TipoSticker.Nube:
                    return new StickerNube(x, y, size, color);
                default:
                    throw new ArgumentException("Tipo de sticker no válido");
            }
        }
    }
}
